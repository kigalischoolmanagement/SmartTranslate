package com.smart.translate
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
  lateinit var key: EditText; lateinit var lang: Spinner; lateinit var qual: Spinner; lateinit var status: TextView
  val langs = listOf("Kinyarwanda", "English", "French", "Swahili", "Spanish", "Arabic", "Chinese", "Portuguese", "German", "Hindi")
  val quals = listOf("Best quality (gemini-2.5-flash)" to "gemini-2.5-flash", "Fastest (gemini-2.5-flash-lite)" to "gemini-2.5-flash-lite")
  fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
  fun grad(c1: String, c2: String, r: Int) = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.parseColor(c1), Color.parseColor(c2))).apply { cornerRadius = dp(r).toFloat() }
  fun tv(t: String, s: Float, c: String) = TextView(this).apply { text = t; textSize = s; setTextColor(Color.parseColor(c)); setPadding(0, dp(8), 0, dp(4)) }

  override fun onCreate(b: Bundle?) {
    super.onCreate(b)
    val p = getSharedPreferences("s", 0)
    val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(22), dp(40), dp(22), dp(24)); background = grad("#0B1030", "#2A1065") }
    root.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, LinearLayout.LayoutParams(dp(96), dp(96)))
    root.addView(tv("Smart Translate", 26f, "#FFFFFF").apply { gravity = Gravity.CENTER })
    root.addView(tv("AI screen translator - text, sign language, voice", 13f, "#9FB4FF").apply { gravity = Gravity.CENTER })
    val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(16)); background = GradientDrawable().apply { setColor(Color.parseColor("#22FFFFFF")); cornerRadius = dp(20).toFloat() } }
    card.addView(tv("1. Gemini API key (free at aistudio.google.com/apikey)", 13f, "#FFFFFF"))
    key = EditText(this).apply { hint = "Paste API key"; setText(p.getString("key", "")); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); inputType = 129; setSingleLine() }
    card.addView(key)
    card.addView(Button(this).apply { text = "Test key"; setTextColor(Color.WHITE); background = grad("#3A4A9F", "#5B3FBF", 18); setOnClickListener { test() } }, LinearLayout.LayoutParams(-1, dp(42)))
    card.addView(tv("2. Translate screen into", 13f, "#FFFFFF"))
    lang = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, langs); setSelection(langs.indexOf(p.getString("lang", "Kinyarwanda")).coerceAtLeast(0)) }
    card.addView(lang)
    card.addView(tv("3. Mode", 13f, "#FFFFFF"))
    qual = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, quals.map { it.first }); setSelection(quals.indexOfFirst { it.second == p.getString("model", "gemini-2.5-flash") }.coerceAtLeast(0)) }
    card.addView(qual)
    root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })
    root.addView(Button(this).apply { text = "START FLOATING BUTTON"; setTextColor(Color.WHITE); background = grad("#00C6FF", "#C400FF", 28); setOnClickListener { start() } }, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(20) })
    root.addView(Button(this).apply { text = "Stop"; setTextColor(Color.WHITE); background = grad("#444B6E", "#444B6E", 28); setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)); toast("Stopped") } }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(10) })
    status = tv("Tap the floating logo in any app, then choose Translate, Sign, Speak, or ask by typing or mic.", 12f, "#9FB4FF").apply { gravity = Gravity.CENTER }
    root.addView(status)
    setContentView(ScrollView(this).apply { addView(root); isFillViewport = true; setBackgroundColor(Color.parseColor("#0B1030")) })
  }
  fun toast(t: String) = runOnUiThread { Toast.makeText(this, t, Toast.LENGTH_LONG).show() }
  fun save() = getSharedPreferences("s", 0).edit().putString("key", key.text.toString().trim()).putString("lang", lang.selectedItem.toString()).putString("model", quals[qual.selectedItemPosition].second).apply()
  fun test() {
    save(); Thread {
      try {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models").openConnection() as HttpURLConnection
        c.setRequestProperty("x-goog-api-key", key.text.toString().trim())
        toast(if (c.responseCode == 200) "Key works!" else "Key rejected (${c.responseCode}). Check it.")
      } catch (e: Exception) { toast("No internet: ${e.message}") }
    }.start()
  }
  fun start() {
    if (key.text.isBlank()) { toast("Paste your Gemini API key first"); return }
    save()
    if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS", "android.permission.RECORD_AUDIO"), 1) else if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf("android.permission.RECORD_AUDIO"), 1)
    if (!Settings.canDrawOverlays(this)) { toast("Allow 'Display over other apps', come back and press Start again"); startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return }
    startActivityForResult((getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent(), 7)
  }
  @Deprecated("x") override fun onActivityResult(r: Int, c: Int, d: Intent?) {
    if (r == 7 && c == RESULT_OK && d != null) {
      val i = Intent(this, OverlayService::class.java).putExtra("code", c).putExtra("data", d)
      if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
      moveTaskToBack(true)
    }
  }
}
